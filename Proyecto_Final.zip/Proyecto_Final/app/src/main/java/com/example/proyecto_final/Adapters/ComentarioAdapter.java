package com.example.proyecto_final.Adapters;

import android.annotation.SuppressLint;
import android.content.Context;
import android.graphics.Color;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import com.example.proyecto_final.Api.Actions.Interfaces.UserInterface;
import com.example.proyecto_final.Api.Actions.UserActions;
import com.example.proyecto_final.R;
import com.example.proyecto_final.Webservice.PeticionesRed;
import com.example.proyecto_final.Webservice.modelo.Gimnasio_comentarios;
import com.example.proyecto_final.Webservice.modelo.Usuario;

import java.util.Date;
import java.util.List;

public class ComentarioAdapter extends RecyclerView.Adapter<ComentarioAdapter.ComentarioViewHolder> implements UserInterface {

    Context context;
    List<Gimnasio_comentarios>lista;
    final static String COLA_PETICIONES="PeticionComentario";
    private PeticionesRed peticionesRed;
    public ComentarioAdapter(Context context, List<Gimnasio_comentarios>lista){
        this.context=context;
        this.lista=lista;
    }

    public static class ComentarioViewHolder extends RecyclerView.ViewHolder{

        TextView tv_nombre,tv_valoracion,tv_comentario,tv_fecha;

        public ComentarioViewHolder(@NonNull View itemView) {
            super(itemView);
            tv_nombre=itemView.findViewById(R.id.tv_nombreUsuario);
            tv_comentario=itemView.findViewById(R.id.tv_comentario);
            tv_fecha=itemView.findViewById(R.id.tv_fecha);
            tv_valoracion=itemView.findViewById(R.id.tv_valoracion);

            itemView.setBackgroundColor(Color.WHITE);

        }
    }

    @NonNull
    @Override
    public ComentarioViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View itemview= LayoutInflater.from(parent.getContext()).inflate(R.layout.item_comentario,parent,false);
        return new ComentarioViewHolder(itemview);
    }

    @SuppressLint("SetTextI18n")
    @Override
    public void onBindViewHolder(@NonNull ComentarioViewHolder holder, int position) {
        peticionesRed=PeticionesRed.getInstancia(context);
        Gimnasio_comentarios comentario=lista.get(position);
        holder.tv_valoracion.append(String.valueOf(comentario.getValoracion()));
        holder.tv_comentario.setText(comentario.getComentario());

        Date fechapublicacion=comentario.getFecha();
        Log.e("fecha",fechapublicacion+" ");
        Date fechaActual = new Date(); // Obtiene la fecha y hora actual

        // Calcula la diferencia de tiempo en milisegundos
        long diferenciaMilisegundos = fechaActual.getTime() - fechapublicacion.getTime();
        long segundos = diferenciaMilisegundos / 1000;
        long minutos = segundos / 60;
        long horas = minutos / 60;
        long dias = horas / 24;
        long semana = dias / 7;
        long meses = dias / 4;
        if(segundos>0 && segundos<60){
            holder.tv_fecha.append(segundos+" seg.");
        }
        else if(minutos>0 && minutos <60){
            holder.tv_fecha.append(minutos+" min");
        }
        else if(horas>0 && horas <24){
            holder.tv_fecha.append(horas+" h");
        }
        else if(dias >0 && dias<7){
            holder.tv_fecha.append(dias+" d.");
        }
        else if(semana>0 && semana<4){
            holder.tv_fecha.append(semana+" sem.");
        }
        else if(meses>0 && meses <12){
            holder.tv_fecha.append(meses+" m");
        }
        UserActions.getID(COLA_PETICIONES,peticionesRed,comentario.getId_usuario(),holder.tv_nombre,this);

    }

    @Override
    public int getItemCount() {
        if(lista !=null){
            return lista.size();
        }
        else {return 0;}
    }

    @SuppressLint("SetTextI18n")
    @Override
    public void onSuccesGetUsuarioID(Usuario usuario, TextView tv_usuario) {
        UserInterface.super.onSuccesGetUsuarioID(usuario, tv_usuario);
        tv_usuario.setText("@"+usuario.getNombre());
    }

    @Override
    public void onFaileureGetUsuarioID(String error) {
        UserInterface.super.onFaileureGetUsuarioID(error);
        Toast.makeText(context, "Error: "+error, Toast.LENGTH_SHORT).show();
    }

}
