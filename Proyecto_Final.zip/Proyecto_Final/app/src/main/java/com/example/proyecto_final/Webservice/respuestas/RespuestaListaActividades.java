package com.example.proyecto_final.Webservice.respuestas;


import com.example.proyecto_final.Webservice.modelo.Actividad;

import java.util.List;

public class RespuestaListaActividades {
    public String status;
    public List<Actividad>data;
}
