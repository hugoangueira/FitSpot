package com.example.proyecto_final.Webservice.respuestas;


import com.example.proyecto_final.Webservice.modelo.Usuario;

public class RespuestaUsuario {
    public String status;
    public Usuario data;
}
