package com.example.proyecto_final.Adapters;

import android.annotation.SuppressLint;
import android.content.Context;
import android.os.AsyncTask;
import android.widget.TextView;

import com.example.proyecto_final.Utilidades;
import com.example.proyecto_final.Webservice.modelo.Gimnasio;

import java.text.DecimalFormat;

public class Obtenerdistancia extends AsyncTask<Void, Void, String>  {

    double latitud,longitud,latitudActual,longitudActual;
    @SuppressLint("StaticFieldLeak")
    Context context;
    @SuppressLint("StaticFieldLeak")
    TextView tv;
    Gimnasio gimnasio;

    public Obtenerdistancia(double latitud, double longitud, Context context, TextView tv, double latitudActual, double longitudActual ) {
        this.latitud=latitud;
        this.longitud=longitud;
        this.context=context;
        this.tv=tv;
        this.longitudActual=longitudActual;
        this.latitudActual=latitudActual;
    }

    @Override
    protected String doInBackground(Void... voids) {
            Utilidades utilidades = new Utilidades();

            DecimalFormat df = new DecimalFormat("#.00000000");
            String latitudform=df.format(latitud);
            String longitudform=df.format(longitud);
            String json = utilidades.getInfo("https://maps.googleapis.com/maps/api/distancematrix/json?units=metric&origins=" + latitudActual + "," + longitudActual +
                    "&destinations=" + latitudform + "," + longitudform + "&key= AIzaSyA1yVLoDXRyNZ3BYdNTVXqx0MFtXRlSXiw");

            return json;
    }

    @SuppressLint("SetTextI18n")
    @Override
    protected void onPostExecute(String s) {
        super.onPostExecute(s);
        if(s==null){
            tv.setText("");
        }
        else{
            double distancia=Double.parseDouble(s);
           tv.setText(s+" km de tu ubicación");
        }
    }

}
