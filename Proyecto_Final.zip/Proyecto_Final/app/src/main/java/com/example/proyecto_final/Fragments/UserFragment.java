package com.example.proyecto_final.Fragments;

import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Bundle;

import androidx.fragment.app.Fragment;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

import com.example.proyecto_final.Activities.Login_Activity;
import com.example.proyecto_final.Adapters.GimnasioAdapter;
import com.example.proyecto_final.Api.Actions.GimnasioActions;
import com.example.proyecto_final.Api.Actions.Interfaces.GimnasioInterface;
import com.example.proyecto_final.R;
import com.example.proyecto_final.Activities.Ventanagimnasio_Activity;
import com.example.proyecto_final.Utilidades;
import com.example.proyecto_final.Webservice.PeticionesRed;
import com.example.proyecto_final.Webservice.modelo.Gimnasio;
import com.example.proyecto_final.Webservice.modelo.Usuario;

import org.json.JSONException;
import org.json.JSONObject;

import java.util.List;


public class UserFragment extends Fragment implements GimnasioInterface{

    private List<Gimnasio>gymList;
    private RecyclerView userRecyclerView;
    private GimnasioAdapter gimnasioAdapter;
    private ImageView img_cerrarSesion;
    private TextView tv_usuario,tv_email;
    private View root;
    private PeticionesRed peticionesRed;
    final static String COLA_PETICIONES="Peticiones User";

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        root= inflater.inflate(R.layout.fragment_user, container, false);
        initvalues();
        initactions();


        return root;
    }
    public void initvalues(){
        img_cerrarSesion=root.findViewById(R.id.img_close);
        userRecyclerView=root.findViewById(R.id.UserRecyclerView);
        tv_email=root.findViewById(R.id.tv_emailusuarioUser);
        tv_usuario=root.findViewById(R.id.tv_nombreusuarioUser);
        userRecyclerView.setLayoutManager(new LinearLayoutManager(getActivity()));
        peticionesRed=PeticionesRed.getInstancia(getContext());
        GimnasioActions.getGimnasio(peticionesRed,COLA_PETICIONES,this);
        try {
            SharedPreferences preferences=Utilidades.getPreferences(getContext());
            String json=preferences.getString("user","");
            Usuario usuario=Usuario.toObject(new JSONObject(json));
            tv_usuario.setText(usuario.getNombre());
            tv_email.setText(usuario.getEmail());
        } catch (JSONException e) {
            throw new RuntimeException(e);
        }
    }
    public void initactions(){
        img_cerrarSesion.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {closeSession();}
        });
    }


    private void closeSession(){
        SharedPreferences preferences= Utilidades.getPreferences(getContext());
        SharedPreferences.Editor editor= preferences.edit();
        editor.remove("user");
        editor.apply();
        Intent cerrarSesion=new Intent(getContext(), Login_Activity.class);
        startActivity(cerrarSesion);

    }
    private void clickgimnasio(int pos){
        Gimnasio gim=gymList.get(pos);
        Intent pasar=new Intent(getContext(), Ventanagimnasio_Activity.class);
        pasar.putExtra("gimnasio",gim);
        startActivity(pasar);
    }



    @Override
    public void onSuccesGetGimnasio(List<Gimnasio> listagim) {
        GimnasioInterface.super.onSuccesGetGimnasio(listagim);
        gymList=listagim;
        gimnasioAdapter=new GimnasioAdapter(listagim,getContext(),"vacio",getActivity());
        gimnasioAdapter.setOnItemClick(new GimnasioAdapter.OnItemClickLis() {
            @Override
            public void onItemClick(View v, int position) {
                clickgimnasio(position);
            }
        });
        userRecyclerView.setAdapter(gimnasioAdapter);

    }

    @Override
    public void onFailureGetGimnasio(String e) {
        GimnasioInterface.super.onFailureGetGimnasio(e);
        Toast.makeText(getContext(), e, Toast.LENGTH_SHORT).show();
    }




}