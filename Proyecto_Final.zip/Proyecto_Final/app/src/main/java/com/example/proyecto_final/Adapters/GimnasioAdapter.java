package com.example.proyecto_final.Adapters;

import android.Manifest;
import android.annotation.SuppressLint;
import android.app.Activity;
import android.content.Context;
import android.graphics.Color;
import android.location.Location;
import android.location.LocationListener;
import android.location.LocationManager;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import com.example.proyecto_final.Api.Actions.ActividadActions;
import com.example.proyecto_final.Api.Actions.Interfaces.Actividadinterface;
import com.example.proyecto_final.Webservice.modelo.GimnasioItem;
import com.example.proyecto_final.R;
import com.example.proyecto_final.Utilidades;
import com.example.proyecto_final.Webservice.PeticionesRed;
import com.example.proyecto_final.Webservice.modelo.Gimnasio;
import com.squareup.picasso.Picasso;

import java.util.ArrayList;
import java.util.List;

public class GimnasioAdapter extends RecyclerView.Adapter<GimnasioAdapter.GimnasioViewHolder> implements Actividadinterface {

    private List<Gimnasio>lista=new ArrayList<>();
    Context contexto;
    String filtrado,actividad;
    static final String COLA_PETICIONES="PeticionesGimnasios";
    private PeticionesRed peticionesRed;
    List<GimnasioItem>listafiltrar=new ArrayList<>();
    private Activity activity;
    private LocationListener mLocationListener,mLocationListener2;
    private LocationManager locationManager;
    private boolean ignoreNextLocationUpdate=false;
    private double longitudActual,latitudActual;
    TextView tv_km;

    public GimnasioAdapter(List<Gimnasio> lista,Context contexto,String filtrado,Activity activity) {
        this.lista = lista;
        this.contexto=contexto;
        this.filtrado=filtrado;
        this.activity=activity;
    }
    public GimnasioAdapter(List<GimnasioItem>listafiltrar,Context contexto,String filtrado,String actividad,Activity activity){
        this.listafiltrar=listafiltrar;
        this.contexto=contexto;
        this.filtrado=filtrado;
        this.actividad=actividad;
        this.activity=activity;
    }
    public static class GimnasioViewHolder extends RecyclerView.ViewHolder{
        ImageView img;
        TextView tv_nombre,tv_actividades,tv_km,tv_precio;

        public GimnasioViewHolder(@NonNull View itemView) {
            super(itemView);
            img=itemView.findViewById(R.id.GymImage);
            tv_nombre=itemView.findViewById(R.id.tv_GymName);
            tv_actividades=itemView.findViewById(R.id.tv_activities);
            tv_km=itemView.findViewById(R.id.tv_km);
            tv_precio=itemView.findViewById(R.id.tv_precio);

            itemView.setBackgroundColor(Color.WHITE);

            itemView.setOnClickListener(v -> {
               if(listener!=null) listener.onItemClick(v,getAdapterPosition());
            });

        }
    }

    @NonNull
    @Override
    public GimnasioViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View itemView= LayoutInflater.from(parent.getContext()).inflate(R.layout.item_gimnasio,parent,false);
        return new GimnasioViewHolder(itemView);
    }

    @SuppressLint("NotifyDataSetChanged")
    @Override
    public void onBindViewHolder(@NonNull GimnasioViewHolder holder, int position) {
            peticionesRed=PeticionesRed.getInstancia(contexto);
            this.locationManager =(LocationManager) activity.getSystemService(Context.LOCATION_SERVICE);
            mostrarUbicacionUsuario();
            if(filtrado.equals("filtrando")){
                GimnasioItem gymitem=listafiltrar.get(position);

                Picasso.with(contexto).load(gymitem.getImagen()).into(holder.img);
                holder.tv_nombre.setText(gymitem.getNombre_gimnasio());
                calcularDistancia(gymitem.getLatitud(),gymitem.getLongitud(),holder.tv_km);
                holder.tv_actividades.setText(actividad);

                holder.tv_precio.setVisibility(View.VISIBLE);
                holder.tv_precio.append(String.valueOf(gymitem.getPrecio_sesion()));
            }
            else if (filtrado.equals("vacio")) {
                Gimnasio gymitem=lista.get(position);
                calcularDistancia(gymitem.getLatitud(),gymitem.getLongitud(),holder.tv_km);
                Picasso.with(contexto).load(gymitem.getImagen()).into(holder.img);
                holder.tv_nombre.setText(gymitem.getNombre_gimnasio());
                holder.tv_actividades.setText("");
                holder.tv_precio.setVisibility(View.GONE);
                ActividadActions.getItemGimnasio(holder.tv_actividades,gymitem.getId(),COLA_PETICIONES,peticionesRed, this);
            }
    }

    public void calcularDistancia(double latitud,double longitud,TextView tv){
        Obtenerdistancia obtenerdistancia= new Obtenerdistancia(latitud,longitud,contexto,tv,latitudActual,longitudActual);
        obtenerdistancia.execute();


    }


  /*public void ordenarPorDistancia() {
        Collections.sort(lista, new Comparator<Gimnasio>() {
            @Override
            public int compare(Gimnasio gim1, Gimnasio gim2) {
                double distancia1 = calcularDistancia(gim1.getLatitud(),gim1.getLongitud());
                double distancia2 = calcularDistancia(gim2.getLatitud(),gim2.getLongitud());
                return Double.compare(distancia1, distancia2);
            }
        });
        notifyDataSetChanged(); // Notificar al RecyclerView que los datos han cambiado
    }*/

    @Override
    public int getItemCount() {
        if(lista.isEmpty()){
            return listafiltrar.size();
        }
        else{
            return lista.size();
        }
    }

    public interface OnItemClickLis{
        void onItemClick(View v,int position);
    }
    static OnItemClickLis listener;
    public void setOnItemClick(OnItemClickLis listener){this.listener=listener;}


    @Override
    public void onSuccesGet(List<GimnasioItem> lista, TextView tv) {
        Actividadinterface.super.onSuccesGet(lista,tv);
        StringBuilder actividades=new StringBuilder();
        for (int i=0;i<lista.size(); i++){
            GimnasioItem gim=lista.get(i);
            actividades.append(gim.getNombre());
            if(i<lista.size()-1){
                actividades.append(", ");
            }
        }
        tv.setText(actividades);
    }

    @Override
    public void onFaileureGet(String e) {
        Actividadinterface.super.onFaileureGet(e);
        Toast.makeText(contexto, e, Toast.LENGTH_SHORT).show();
    }
    @SuppressLint("MissingPermission")
    private void mostrarUbicacionUsuario() {
        if (!Utilidades.tienePermiso(activity, Manifest.permission.ACCESS_FINE_LOCATION)) {
            Utilidades.solicitarPermisosUbicacion(activity);
            return;
        }

        mLocationListener = new LocationListener() {

            @Override
            public void onStatusChanged(String provider, int status, Bundle extras) {
                // TODO Auto-generated method stub

            }

            @Override
            public void onProviderEnabled(@NonNull String provider) {
                // TODO Auto-generated method stub

            }

            @Override
            public void onProviderDisabled(@NonNull String provider) {
                // TODO Auto-generated method stub

            }

            @Override
            public void onLocationChanged(@NonNull Location location) {
                // TODO Auto-generated method stub


                if (!ignoreNextLocationUpdate) {
                    ignoreNextLocationUpdate = true;
                }

            }
        };

        mLocationListener2 = new LocationListener() {

            @Override
            public void onStatusChanged(String provider, int status, Bundle extras) {
                // TODO Auto-generated method stub

            }

            @Override
            public void onProviderEnabled(@NonNull String provider) {
                // TODO Auto-generated method stub

            }

            @Override
            public void onProviderDisabled(@NonNull String provider) {
                // TODO Auto-generated method stub

            }

            @Override
            public void onLocationChanged(@NonNull Location location) {
                // TODO Auto-generated method stub

                if (!ignoreNextLocationUpdate) {
                    ignoreNextLocationUpdate = true;
                }
            }
        };


        if (!Utilidades.tienePermiso(activity, Manifest.permission.ACCESS_FINE_LOCATION)) {
            Utilidades.solicitarPermisosUbicacion(activity);
        } else {

            locationManager.requestLocationUpdates(LocationManager.GPS_PROVIDER, 1000,
                    1, mLocationListener);

            locationManager.requestLocationUpdates(LocationManager.NETWORK_PROVIDER, 0,
                    0, mLocationListener2);

            Location location = locationManager.getLastKnownLocation(LocationManager.GPS_PROVIDER);
            if (location == null) {
                location = locationManager.getLastKnownLocation(LocationManager.NETWORK_PROVIDER);
            }
            if (location != null) {
                longitudActual=location.getLongitude();
                latitudActual=location.getLatitude();
            }
        }
    }

}

