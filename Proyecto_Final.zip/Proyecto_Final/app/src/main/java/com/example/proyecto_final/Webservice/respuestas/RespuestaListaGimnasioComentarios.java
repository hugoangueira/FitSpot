package com.example.proyecto_final.Webservice.respuestas;

import com.example.proyecto_final.Webservice.modelo.Gimnasio_comentarios;

import java.util.List;

public class RespuestaListaGimnasioComentarios {

    public String status;
    public List<Gimnasio_comentarios>data;

}
