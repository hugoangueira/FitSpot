package com.example.proyecto_final.Api.Actions.Interfaces;

import com.example.proyecto_final.Webservice.modelo.Gimnasio;

import java.util.List;

public interface GimnasioInterface {

    default void onSuccesGetGimnasio(List<Gimnasio> listagim){

    }
    default void onFailureGetGimnasio(String e){

    }
    default void onSuccesGetGimnasiosOrdenated(List<Gimnasio> listagim){

    }
    default void onFailureGetGimnasiosOrdenated(String error){

    }

}
