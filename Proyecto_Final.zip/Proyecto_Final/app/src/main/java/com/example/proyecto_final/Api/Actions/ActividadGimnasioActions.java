package com.example.proyecto_final.Api.Actions;

import android.widget.TextView;

import com.android.volley.Request;
import com.android.volley.Response;
import com.android.volley.VolleyError;
import com.android.volley.toolbox.JsonObjectRequest;
import com.example.proyecto_final.Api.Actions.Interfaces.ActividadGimnasioInterface;
import com.example.proyecto_final.Utilidades;
import com.example.proyecto_final.Webservice.PeticionesRed;
import com.example.proyecto_final.Webservice.WebService;
import com.example.proyecto_final.Webservice.respuestas.RespuestaListaActGimnasio;
import com.example.proyecto_final.Webservice.respuestas.RespuestaListaActividades;
import com.example.proyecto_final.Webservice.respuestas.RespuestaListaGimnasioActividad;
import com.google.gson.Gson;
import com.google.gson.GsonBuilder;

import org.json.JSONObject;

import java.util.HashMap;

import javax.xml.xpath.XPathFunctionResolver;

public class ActividadGimnasioActions {

    public static void getGimnasioFiltrar(String COLA_PETICIONES,PeticionesRed peticionesRed,String actividad,String precio,final ActividadGimnasioInterface callback){
        HashMap<String,String>parametros=new HashMap<>();
        parametros.put("nombre",actividad);
        parametros.put("precio",precio);

        String url=WebService.URL_Gimnasio_Actividad+Utilidades.generaParametrosURL(parametros);

        JsonObjectRequest jsonObjectRequest=new JsonObjectRequest(Request.Method.GET, url, null, new Response.Listener<JSONObject>() {
            @Override
            public void onResponse(JSONObject jsonObject) {
                Gson gson=new GsonBuilder().create();
                RespuestaListaActGimnasio respuestaListaActGimnasio=gson.fromJson(jsonObject.toString(), RespuestaListaActGimnasio.class);
                if(respuestaListaActGimnasio.data !=null){
                    callback.onSuccesGetFiltrarActividadPrecio(respuestaListaActGimnasio.data,actividad);
                }

            }
        }, new Response.ErrorListener() {
            @Override
            public void onErrorResponse(VolleyError volleyError) {
                callback.onFailureGetFiltrarActividadPrecio("Error: "+volleyError);
            }
        });
        jsonObjectRequest.setTag(COLA_PETICIONES);
        peticionesRed.anhadirPeticionACola(jsonObjectRequest);
    }
    public static void getGimnasioFiltrar2(String COLA_PETICIONES,PeticionesRed peticionesRed,String actividad,final ActividadGimnasioInterface callback){
        HashMap<String,String>parametros=new HashMap<>();
        parametros.put("nombre",actividad);

        String url=WebService.URL_Gimnasio_Actividad+Utilidades.generaParametrosURL(parametros);

        JsonObjectRequest jsonObjectRequest=new JsonObjectRequest(Request.Method.GET, url, null, new Response.Listener<JSONObject>() {
            @Override
            public void onResponse(JSONObject jsonObject) {
                Gson gson=new GsonBuilder().create();
                RespuestaListaActGimnasio respuestaListaActGimnasio=gson.fromJson(jsonObject.toString(), RespuestaListaActGimnasio.class);
                if(respuestaListaActGimnasio.data !=null){
                    callback.onSuccesGetFiltrarActividad(respuestaListaActGimnasio.data,actividad);
                }

            }
        }, volleyError -> {
            callback.onFailureGetFiltrarActividad("Error: "+volleyError);
        });
        jsonObjectRequest.setTag(COLA_PETICIONES);
        peticionesRed.anhadirPeticionACola(jsonObjectRequest);
    }

}
