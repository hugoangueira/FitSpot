package com.example.proyecto_final.Webservice.respuestas;


import com.example.proyecto_final.Webservice.modelo.Coordenadas;

import java.util.List;

public class RespuestaListaCoordenadas {
    public String status;
    public List<Coordenadas>data;
}
