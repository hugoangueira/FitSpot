package com.example.proyecto_final.Webservice.respuestas;

import com.example.proyecto_final.Webservice.modelo.GimnasioItem;

import java.util.List;

public class RespuestaListaActGimnasio {

    public String status;
    public List<GimnasioItem> data;

}
