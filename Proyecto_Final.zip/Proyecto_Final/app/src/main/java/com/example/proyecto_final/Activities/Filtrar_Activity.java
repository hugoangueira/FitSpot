package com.example.proyecto_final.Activities;

import android.content.Intent;
import android.os.Bundle;
import android.util.Log;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.Spinner;

import androidx.appcompat.app.AppCompatActivity;
import androidx.core.content.ContextCompat;

import com.example.proyecto_final.Api.Actions.ActividadActions;
import com.example.proyecto_final.Api.Actions.Interfaces.Actividadinterface;
import com.example.proyecto_final.Fragments.HomeFragment;
import com.example.proyecto_final.R;
import com.example.proyecto_final.Webservice.PeticionesRed;

import java.util.List;

public class Filtrar_Activity extends AppCompatActivity implements Actividadinterface {

    Spinner spinner_actividad,spinner_localidad,spinner_precio;
    Button btn_aceptar,btn_atras;
    PeticionesRed peticionesRed;

    static final String COLA_PETICIONES="PeticionesFiltrar";


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_filtrar);
        getWindow().setStatusBarColor(ContextCompat.getColor(Filtrar_Activity.this,R.color.color_statusBar));

        initvalues();
        initActions();

    }
    public void initvalues(){
        spinner_actividad=findViewById(R.id.spinner_actividad);
        spinner_localidad=findViewById(R.id.spinner_localidad);
        spinner_precio=findViewById(R.id.spinner_precio);
        btn_aceptar=findViewById(R.id.btn_aceptar);
        btn_atras=findViewById(R.id.btn_atras);

        peticionesRed=PeticionesRed.getInstancia(Filtrar_Activity.this);

        String[]localidades={"","Santiago de Compostela","Teo","Ames"};
        ArrayAdapter<String>adaptador_localidades=new ArrayAdapter<>(Filtrar_Activity.this, android.R.layout.simple_spinner_dropdown_item,localidades);
        spinner_localidad.setAdapter(adaptador_localidades);

        String[]precios={"Menor a mayor","Mayor a menor"};
        ArrayAdapter<String>adaptador_precio=new ArrayAdapter<>(Filtrar_Activity.this, android.R.layout.simple_spinner_dropdown_item,precios);
        spinner_precio.setAdapter(adaptador_precio);
        ActividadActions.getActividad(peticionesRed,COLA_PETICIONES,this);

    }
    public void initActions(){
        btn_atras.setOnClickListener(view -> {
            setResult(RESULT_CANCELED);
                finish();
        });
        btn_aceptar.setOnClickListener(view-> {
                Intent abrir = new Intent(Filtrar_Activity.this, HomeFragment.class);
                String actividad = (String) spinner_actividad.getSelectedItem();
                String precio = "";
                if (spinner_precio.getSelectedItem().equals("Menor a mayor")) {
                    precio = "ASC";
                } else if (spinner_precio.getSelectedItem().equals("Mayor a menor")) {
                    precio = "DESC";
                } else {
                    precio = "ASC";
                }
                abrir.putExtra("actividad", actividad);
                abrir.putExtra("precio", precio);
                setResult(RESULT_OK, abrir);
                finish();
        });
    }

    @Override
    public void onSuccesGetActividad(List<String> listaactividad) {
        Actividadinterface.super.onSuccesGetActividad(listaactividad);
        String []actividades=listaactividad.toArray(new String[0]);
        ArrayAdapter<String> adaptador_actividades=new ArrayAdapter<>(Filtrar_Activity.this, android.R.layout.simple_spinner_dropdown_item,actividades);
        spinner_actividad.setAdapter(adaptador_actividades);

    }
}