package com.example.proyecto_final.Fragments;

import static android.app.Activity.RESULT_CANCELED;
import static android.app.Activity.RESULT_OK;

import android.Manifest;
import android.annotation.SuppressLint;
import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.location.Location;
import android.location.LocationListener;
import android.location.LocationManager;
import android.os.Bundle;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.fragment.app.Fragment;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ArrayAdapter;
import android.widget.AutoCompleteTextView;
import android.widget.FrameLayout;
import android.widget.ImageView;
import android.widget.Toast;
import com.example.proyecto_final.Activities.Filtrar_Activity;
import com.example.proyecto_final.Adapters.GimnasioAdapter;
import com.example.proyecto_final.Api.Actions.ActividadGimnasioActions;
import com.example.proyecto_final.Api.Actions.GimnasioActions;
import com.example.proyecto_final.Api.Actions.Interfaces.ActividadGimnasioInterface;
import com.example.proyecto_final.Api.Actions.Interfaces.GimnasioInterface;
import com.example.proyecto_final.Webservice.modelo.GimnasioItem;
import com.example.proyecto_final.R;
import com.example.proyecto_final.Activities.Ventanagimnasio_Activity;
import com.example.proyecto_final.Utilidades;
import com.example.proyecto_final.Webservice.PeticionesRed;
import com.example.proyecto_final.Webservice.modelo.Gimnasio;

import java.util.ArrayList;
import java.util.List;

public class HomeFragment extends Fragment implements GimnasioInterface,ActividadGimnasioInterface{


    private List<Gimnasio>gymList =new ArrayList<>();
    private List<GimnasioItem>gymListitem =new ArrayList<>();
    private RecyclerView homeRecyclerView;
    private GimnasioAdapter gimnasioAdapter;
    static final String COLA_PETICIONES="PeticionesGimnasios";
    private PeticionesRed peticionesRed;
    AutoCompleteTextView autoCompleteTextView;
    FrameLayout filtrar;
    ImageView img7,btn_filtrar;
    String modo="vacio";
    private View rootView;
    private LocationListener mLocationListener,mLocationListener2;
    private LocationManager locationManager;
    private boolean ignoreNextLocationUpdate=false;
    private double longitudActual,latitudActual;

    public HomeFragment() {
        // Required empty public constructor
    }

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        // Inflate the layout for this fragment
        rootView= inflater.inflate(R.layout.fragment_home, container, false);
        initvalues();
        initActions();

        return rootView;
    }

    @Override
    public void onResume() {
        super.onResume();
        autoCompleteTextView.setText("");
    }

    public void initvalues(){
        filtrar=rootView.findViewById(R.id.filtrar);
        autoCompleteTextView =rootView.findViewById(R.id.edt_filtrar);
        img7=rootView.findViewById(R.id.imageView7);
        homeRecyclerView=rootView.findViewById(R.id.homeRecyclerView);
        btn_filtrar=rootView.findViewById(R.id.btn_filtrar);
        homeRecyclerView.setLayoutManager(new LinearLayoutManager(getActivity()));
        peticionesRed=PeticionesRed.getInstancia(getContext());

        this.locationManager =(LocationManager) getActivity().getSystemService(Context.LOCATION_SERVICE);
        mostrarUbicacionUsuario();

        GimnasioActions.getGimnasiosOrdenated(latitudActual,longitudActual,peticionesRed,COLA_PETICIONES,this);

    }
    public void initActions(){
        btn_filtrar.setOnClickListener(view -> {
                Intent filtrar=new Intent(getContext(), Filtrar_Activity.class);
                filtrar.setAction("filtrar");
                startActivityForResult(filtrar,3000);
        });
    }
    private void clickgimnasio(int pos){
        Intent pasar=new Intent(getContext(), Ventanagimnasio_Activity.class);
        if( gymListitem == null ){
            Gimnasio gim=gymList.get(pos);
            pasar.setAction("gimnasio");
            pasar.putExtra("gimnasio",gim);
        }
        else if( gymList == null){
            GimnasioItem gim=gymListitem.get(pos);
            pasar.setAction("gimnasioitem");
            pasar.putExtra("gimnasio",gim);
        }
        startActivity(pasar);
    }

    @Override
    public void onActivityResult(int requestCode, int resultCode, @Nullable Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if(requestCode==3000 && resultCode==RESULT_OK){
            if(data !=null){
                String actividad=data.getStringExtra("actividad");
                String precio=data.getStringExtra("precio");
                autoCompleteTextView.setHint("Filtrando por "+actividad);
                modo="filtrando";

                ActividadGimnasioActions.getGimnasioFiltrar(COLA_PETICIONES,peticionesRed,actividad,precio,this);
            }
        }
        else if(requestCode == 3000 && resultCode == RESULT_CANCELED){
            autoCompleteTextView.setHint("Filtrar");
            modo="vacio";
            GimnasioActions.getGimnasio(peticionesRed,COLA_PETICIONES,this);
        }
    }
    public void updateInterfaz(List<Gimnasio>listagim){
        gymList=listagim;
        gymListitem=null;
        gimnasioAdapter=new GimnasioAdapter(listagim,getContext(),modo,getActivity());
        gimnasioAdapter.setOnItemClick((v, position) -> clickgimnasio(position));
        homeRecyclerView.setAdapter(gimnasioAdapter);

    }
    private void updateInterfazFiltrar(List<GimnasioItem>listagim,String actividad){
        gymList=null;
        gymListitem=listagim;
        gimnasioAdapter=new GimnasioAdapter(listagim,getContext(),modo,actividad,getActivity());
        gimnasioAdapter.setOnItemClick((v, position) -> clickgimnasio(position));
        homeRecyclerView.setAdapter(gimnasioAdapter);
    }

    private void rellenarAutocomplete(List<Gimnasio>listagim){
        List<String> nombres=new ArrayList<>();
        for (Gimnasio gim:listagim ) {
            nombres.add(gim.getNombre_gimnasio());
        }
        ArrayAdapter<String>adapter=new ArrayAdapter<>(getActivity(), android.R.layout.simple_dropdown_item_1line,nombres);
        autoCompleteTextView.setOnItemClickListener((parent, view, position, id) -> {
            String nombre= (String) parent.getItemAtPosition(position);
            for (Gimnasio g:listagim ) {
                if(nombre.equals(g.getNombre_gimnasio())){
                    Intent pasar=new Intent(getContext(), Ventanagimnasio_Activity.class);
                    pasar.setAction("gimnasio");
                    pasar.putExtra("gimnasio",g);
                    startActivity(pasar);
                }
            }
        });
        autoCompleteTextView.setAdapter(adapter);
    }
    @SuppressLint("MissingPermission")
    private void mostrarUbicacionUsuario() {
        if (!Utilidades.tienePermiso(getActivity(), Manifest.permission.ACCESS_FINE_LOCATION)) {
            Utilidades.solicitarPermisosUbicacion(getActivity());
            return;
        }

        mLocationListener = new LocationListener() {

            @Override
            public void onStatusChanged(String provider, int status, Bundle extras) {
                // TODO Auto-generated method stub

            }

            @Override
            public void onProviderEnabled(@NonNull String provider) {
                // TODO Auto-generated method stub

            }

            @Override
            public void onProviderDisabled(@NonNull String provider) {
                // TODO Auto-generated method stub

            }

            @Override
            public void onLocationChanged(@NonNull Location location) {
                // TODO Auto-generated method stub


                if (!ignoreNextLocationUpdate) {
                    ignoreNextLocationUpdate = true;
                }

            }
        };

        mLocationListener2 = new LocationListener() {

            @Override
            public void onStatusChanged(String provider, int status, Bundle extras) {
                // TODO Auto-generated method stub

            }

            @Override
            public void onProviderEnabled(@NonNull String provider) {
                // TODO Auto-generated method stub

            }

            @Override
            public void onProviderDisabled(@NonNull String provider) {
                // TODO Auto-generated method stub

            }

            @Override
            public void onLocationChanged(@NonNull Location location) {
                // TODO Auto-generated method stub

                if (!ignoreNextLocationUpdate) {
                    ignoreNextLocationUpdate = true;
                }
            }
        };


        if (!Utilidades.tienePermiso(getActivity(), Manifest.permission.ACCESS_FINE_LOCATION)) {
            Utilidades.solicitarPermisosUbicacion(getActivity());
        } else {

            locationManager.requestLocationUpdates(LocationManager.GPS_PROVIDER, 1000,
                    1, mLocationListener);

            locationManager.requestLocationUpdates(LocationManager.NETWORK_PROVIDER, 0,
                    0, mLocationListener2);

            Location location = locationManager.getLastKnownLocation(LocationManager.GPS_PROVIDER);
            if (location == null) {
                location = locationManager.getLastKnownLocation(LocationManager.NETWORK_PROVIDER);
            }
            if (location != null) {
                longitudActual=location.getLongitude();
                latitudActual=location.getLatitude();
            }
        }
    }

    @Override
    public void onSuccesGetGimnasiosOrdenated(List<Gimnasio> listagim) {
        GimnasioInterface.super.onSuccesGetGimnasiosOrdenated(listagim);
        updateInterfaz(listagim);
        rellenarAutocomplete(listagim);

        SharedPreferences preferences= Utilidades.getPreferences(getContext());
        SharedPreferences.Editor editor=preferences.edit();
        editor.remove("actividad");
        editor.apply();
    }
    @Override
    public void onFailureGetGimnasiosOrdenated(String error) {
        GimnasioInterface.super.onFailureGetGimnasiosOrdenated(error);
        Toast.makeText(getContext(), error, Toast.LENGTH_SHORT).show();
    }

    @Override
    public void onSuccesGetFiltrarActividadPrecio(List<GimnasioItem> lista, String actividad) {
        ActividadGimnasioInterface.super.onSuccesGetFiltrarActividadPrecio(lista, actividad);
        updateInterfazFiltrar(lista,actividad);

        SharedPreferences preferences= Utilidades.getPreferences(getContext());
        SharedPreferences.Editor editor=preferences.edit();
        editor.putString("actividad",actividad);
        editor.apply();

    }

    @Override
    public void onFailureGetFiltrarActividadPrecio(String error) {
        ActividadGimnasioInterface.super.onFailureGetFiltrarActividadPrecio(error);
        Toast.makeText(getActivity(), error, Toast.LENGTH_SHORT).show();
    }
}