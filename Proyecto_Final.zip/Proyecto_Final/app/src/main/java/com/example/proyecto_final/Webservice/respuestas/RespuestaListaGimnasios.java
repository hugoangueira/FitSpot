package com.example.proyecto_final.Webservice.respuestas;



import com.example.proyecto_final.Webservice.modelo.Gimnasio;

import java.util.List;

public class RespuestaListaGimnasios {

    public String status;
    public List<Gimnasio>data;

}
