package com.example.proyecto_final.Webservice.respuestas;



import com.example.proyecto_final.Webservice.modelo.Departamento;

import java.util.List;

public class RespuestaListaDepartamentos {
    public String status;
    public List<Departamento> data;
}
