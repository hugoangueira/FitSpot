package com.example.proyecto_final.Api.Actions.Interfaces;

import com.example.proyecto_final.Webservice.modelo.GimnasioItem;

import java.util.List;

public interface ActividadGimnasioInterface {

    default void onSuccesGetFiltrarActividadPrecio(List<GimnasioItem>lista,String actividad){

    }
    default void onFailureGetFiltrarActividadPrecio(String error){

    }
    default void onSuccesGetFiltrarActividad(List<GimnasioItem>lista,String actividad){

    }
    default void onFailureGetFiltrarActividad(String error){

    }

}
